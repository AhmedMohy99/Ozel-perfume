Ozel-perfume static site

To deploy: upload all files in this folder to a GitHub repo and connect that repo to Vercel. The site is static and requires no build step.

Edit products in products.js (add more objects to the products array).

This package includes multi-language (English/Arabic) toggle that switches directionality (LTR/RTL) and basic translations.