export const SAMPLE_PERFUMES = [
  {
    id: 1,
    name: "Ozel Noir",
    description: "Deep oud and amber notes.",
    price: 120,
    image: "https://via.placeholder.com/300x400.png?text=Ozel+Noir"
  },
  {
    id: 2,
    name: "Ozel Bloom",
    description: "Floral and fresh everyday wear.",
    price: 95,
    image: "https://via.placeholder.com/300x400.png?text=Ozel+Bloom"
  }
]
