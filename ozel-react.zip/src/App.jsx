import React, { useState } from 'react'
import { SAMPLE_PERFUMES } from './data/SAMPLE_PERFUMES'
import { LOCALES } from './i18n'
import Header from './components/Header'
import PerfumeCard from './components/PerfumeCard'
import PerfumeModal from './components/PerfumeModal'
import Footer from './components/Footer'

export default function App() {
  const [locale, setLocale] = useState('en')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)

  const t = LOCALES[locale]

  const filteredPerfumes = SAMPLE_PERFUMES.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className={locale === 'ar' ? 'ar' : ''}>
      <Header locale={locale} setLocale={setLocale} t={t} />

      <main className="p-6">
        <input
          type="text"
          placeholder={t.search}
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full mb-6 px-4 py-2 border rounded"
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {filteredPerfumes.map(p => (
            <PerfumeCard key={p.id} perfume={p} onClick={setSelected} />
          ))}
        </div>
      </main>

      <Footer />

      <PerfumeModal perfume={selected} onClose={() => setSelected(null)} t={t} />
    </div>
  )
}
