import React from 'react'

export default function Header({ locale, setLocale, t }) {
  return (
    <header className="flex justify-between items-center p-4 bg-white shadow">
      <h1 className="text-xl font-bold">{t.title}</h1>
      <button
        onClick={() => setLocale(locale === 'en' ? 'ar' : 'en')}
        className="px-3 py-1 bg-indigo-500 text-white rounded"
      >
        {locale === 'en' ? 'AR' : 'EN'}
      </button>
    </header>
  )
}
