import React from 'react'

export default function PerfumeModal({ perfume, onClose, t }) {
  if (!perfume) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
      <div className="bg-white rounded-xl shadow-lg max-w-md w-full p-4 relative">
        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-600 hover:text-black"
        >
          ✕
        </button>
        <img src={perfume.image} alt={perfume.name} className="w-full h-64 object-cover rounded" />
        <h2 className="mt-4 text-xl font-bold">{perfume.name}</h2>
        <p className="text-gray-700 mt-2">{t.description}: {perfume.description}</p>
        <p className="font-semibold mt-2">{t.price}: ${perfume.price}</p>
      </div>
    </div>
  )
}
