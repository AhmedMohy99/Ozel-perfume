import React from 'react'

export default function PerfumeCard({ perfume, onClick }) {
  return (
    <div
      onClick={() => onClick(perfume)}
      className="border rounded-xl overflow-hidden shadow hover:shadow-lg transition cursor-pointer"
    >
      <img src={perfume.image} alt={perfume.name} className="w-full h-64 object-cover" />
      <div className="p-3">
        <h2 className="font-semibold text-lg">{perfume.name}</h2>
        <p className="text-gray-600">${perfume.price}</p>
      </div>
    </div>
  )
}
