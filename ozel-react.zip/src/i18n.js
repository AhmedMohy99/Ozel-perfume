export const LOCALES = {
  en: {
    title: "Ozel Perfume Collection",
    search: "Search perfumes...",
    close: "Close",
    description: "Description",
    price: "Price",
  },
  ar: {
    title: "مجموعة عطور أوزيل",
    search: "ابحث عن العطور...",
    close: "إغلاق",
    description: "الوصف",
    price: "السعر",
  }
}
